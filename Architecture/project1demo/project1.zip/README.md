# /*********************************************************************************
# * 
# *  Created by Xiang on 2020/3/9.
# *  Copyright (c) 2020-2021 Xiang. All rights reserved.
# * 
# **********************************************************************************/
#

#  How to Use

## Run: 
    1. make
    2. ./sim test01.asm

    Log will be saved to ./logs/*.log

## Clean:
    make clean
    it will remove pipeline and all the logs directory

# When running the progrm with DEBUGLOG=1, use libpipeline_debug.a instead of libpipeline.a 
