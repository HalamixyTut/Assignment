replace x y [] = []
replace x y (z:zs)
	|z == x = y:replace x y zs
	|otherwise = z:replace x y zs
	
	
	
delete k [] = []
delete k lt
	|(length lt) > k = append (take (k-1) lt)(delete k (drop k lt))
	|otherwise = lt
	
	
maxodd lt
	|(length lt)>2 && (head lt)>(headtail(tail lt)) = maxodd((head lt):(tailtail(tail lt)))
	|(length lt)>2 && (head lt)<=(headtail(tail lt)) = maxodd(tailtail lt)
	|otherwise = head lt
	
union [] [] = []
union lt1 lt2 = deletesame(append lt1 lt2)

headtail x = head(tail x)
tailtail x = tail(tail x)

append [] ys = ys
append (x:xs) ys = x:append xs ys

alldelete x [] = []
alldelete x (y:ys)
	|x == y = alldelete x ys
	|otherwise = y:alldelete x ys

deletesame [] = []
deletesame(x:xs) = x:(deletesame(alldelete x xs))
